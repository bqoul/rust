mod json;

use std::io::{self, Write};
use reqwest::Error;
use json::Forecast;
use colored::*;

#[tokio::main]
async fn main() -> Result<(), Error>{
    let mut city = String::new();

    print!("\nenter city name: ");
    let _ = io::stdout().flush();
    io::stdin().read_line(&mut city).unwrap();

    let link = format!("http://api.weatherapi.com/v1/current.json?key={api_key}&q={city}&aqi=no", 
                       api_key = "fd2fd72448604b59884125806210903", 
                       city = city.trim());

    let response = reqwest::get(&link)
        .await?
        .json::<Forecast>()
        .await?;

    println!("weather in {city}({country}): {weather} | temperature: {c}°C ({f}°F)\n",
        city = response.location.name,
        country = response.location.country,
        weather = response.current.condition.text.black().on_white(), 
        c = response.current.temp_c.to_string().black().on_white(),
        f = response.current.temp_f.to_string().black().on_white());

    Ok(())
}
