//adding bracers to a number if its < 0
pub fn bracers(number: i32) -> String {
    let mut string = number.to_string();
    if number < 0 {
        string = format!("({})", string);
    }
    string
}
