mod format; //using the format.rs file

use colored::*;
use rand::Rng;
use std::io::{self, Write}; //need this to flush after print!

fn main() {
    print!("range (min): ");
    let _ = io::stdout().flush();
    //flushing after every print! to make user input on the same line

    let mut min = String::new();
    io::stdin()
        .read_line(&mut min)
        .expect("input error (min)");
    
    print!("range (max): ");
    let _ = io::stdout().flush();

    let mut max = String::new();
    io::stdin()
        .read_line(&mut max)
        .expect("input error (max)");

    let min: i32 = min
        .trim()
        .parse()
        .expect("parsing error (min)");
    let max: i32 = max
        .trim()
        .parse()
        .expect("parsing error (max)");

    loop {
        let num_1 = rand::thread_rng().gen_range(min..max + 1);
        let num_2 = rand::thread_rng().gen_range(min..max + 1); let answer;

        //generating a number in range 1-4 to make different mathematical operations 
        let operation = rand::thread_rng().gen_range(1..5);
        if operation == 1 {
            print!("\n{} ⋅ {} = ", format::bracers(num_1), format::bracers(num_2)); 
            answer = (num_1 * num_2).to_string(); 
        } else if operation == 2 {
            print!("\n{} - {} = ", format::bracers(num_1), format::bracers(num_2));
            answer = (num_1 - num_2).to_string();
        } else if operation == 3 && num_2 != 0 && num_1 % num_2 == 0 {
            print!("\n{} : {} = ", format::bracers(num_1), format::bracers(num_2));
            answer = (num_1 / num_2).to_string();
        } else { //for some reason "answer" freaking out if im using "else if operation == 4"
            print!("\n{} + {} = ", format::bracers(num_1), format::bracers(num_2));
            answer = (num_1 + num_2).to_string();
        }
        let _ = io::stdout().flush();        

        let mut user_input = String::new();
        io::stdin()
            .read_line(&mut user_input)
            .expect("input error (answer)");

        if user_input.trim() == answer {
            println!("{}", "correct!".on_green());
        } else {
            println!("{}", "wrong!".on_red());
        }
    }
}
