use std::io::{self, Write};
use colored::*;

fn main() {
    loop {
        let mut a = String::new();
        let mut b = String::new();
        let mut c = String::new();

        print!("{} = ", "a".bright_red()); 
        let _ = io::stdout().flush();
        io::stdin().read_line(&mut a).expect("a input error");

        print!("{} = ", "b".bright_blue());
        let _ = io::stdout().flush();
        io::stdin().read_line(&mut b).expect("b input error");

        print!("{} = ", "c".bright_green());
        let _ = io::stdout().flush();
        io::stdin().read_line(&mut c).expect("c input error");

        let a: f64 = a.trim().parse().expect("parsing error (a)");
        let b: f64 = b.trim().parse().expect("parsing error (b)");
        let c: f64 = c.trim().parse().expect("parsing error (c)");

        let disc = b * b - 4.0 * a * c; 
        println!("\nD = {}", disc);

        if disc == 0.0 {
            let x = -b + disc.sqrt() / 2.0 * a;
            println!("x = {}\n", x);
        } else if disc < 0.0 {
            println!("no roots\n");
        } else {
            let x1 = (-b + disc.sqrt()) / (2.0 * a);
            let x2 = (-b - disc.sqrt()) / (2.0 * a);
            println!("x1 = {}", x1);
            println!("x2 = {}\n", x2);
        }
    }
}
